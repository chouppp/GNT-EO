/*
 Navicat Premium Dump SQL

 Source Server         : local
 Source Server Type    : MySQL
 Source Server Version : 80040 (8.0.40)
 Source Host           : localhost:3306
 Source Schema         : nfv_link

 Target Server Type    : MySQL
 Target Server Version : 80040 (8.0.40)
 File Encoding         : 65001

 Date: 24/10/2026 15:05:05
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for link_single_table
-- ----------------------------
DROP TABLE IF EXISTS `link_single_table`;
CREATE TABLE `link_single_table`  (
  `link_id` int NOT NULL AUTO_INCREMENT,
  `source_node` int NULL DEFAULT NULL,
  `destination_node` int NULL DEFAULT NULL,
  `bw_resource` int NULL DEFAULT NULL,
  `bw_max_resource` int NULL DEFAULT NULL,
  `current_flow` float NULL DEFAULT NULL,
  `egress_port` int NULL DEFAULT NULL,
  `next_hop_mac` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`link_id`) USING BTREE,
  INDEX `idx_link_src_dst`(`source_node` ASC, `destination_node` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1241 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of link_single_table
-- ----------------------------
INSERT INTO `link_single_table` VALUES (1, 0, 1, 87, 87, 0, 2, '00:00:0a:02:02:01');
INSERT INTO `link_single_table` VALUES (2, 0, 3, 64, 64, 0, 3, '00:00:0a:04:02:01');
INSERT INTO `link_single_table` VALUES (3, 0, 5, 68, 68, 0, 4, '00:00:0a:06:02:01');
INSERT INTO `link_single_table` VALUES (4, 0, 11, 74, 74, 0, 5, '00:00:0a:12:02:01');
INSERT INTO `link_single_table` VALUES (5, 0, 12, 82, 82, 0, 6, '00:00:0a:13:02:01');
INSERT INTO `link_single_table` VALUES (6, 0, 21, 75, 75, 0, 7, '00:00:0a:22:02:01');
INSERT INTO `link_single_table` VALUES (7, 0, 24, 60, 60, 0, 8, '00:00:0a:25:02:01');
INSERT INTO `link_single_table` VALUES (8, 1, 0, 78, 78, 0, 2, '00:00:0a:01:02:01');
INSERT INTO `link_single_table` VALUES (9, 1, 2, 72, 72, 0, 3, '00:00:0a:03:02:01');
INSERT INTO `link_single_table` VALUES (10, 1, 3, 85, 85, 0, 4, '00:00:0a:04:03:01');
INSERT INTO `link_single_table` VALUES (11, 1, 4, 82, 82, 0, 5, '00:00:0a:05:02:01');
INSERT INTO `link_single_table` VALUES (12, 1, 11, 69, 69, 0, 6, '00:00:0a:12:03:01');
INSERT INTO `link_single_table` VALUES (13, 1, 12, 88, 88, 0, 7, '00:00:0a:13:03:01');
INSERT INTO `link_single_table` VALUES (14, 1, 14, 85, 85, 0, 8, '00:00:0a:15:02:01');
INSERT INTO `link_single_table` VALUES (15, 1, 16, 79, 79, 0, 9, '00:00:0a:17:02:01');
INSERT INTO `link_single_table` VALUES (16, 1, 18, 85, 85, 0, 10, '00:00:0a:19:02:01');
INSERT INTO `link_single_table` VALUES (17, 1, 19, 81, 81, 0, 11, '00:00:0a:20:02:01');
INSERT INTO `link_single_table` VALUES (18, 1, 20, 79, 79, 0, 12, '00:00:0a:21:02:01');
INSERT INTO `link_single_table` VALUES (19, 1, 21, 60, 60, 0, 13, '00:00:0a:22:03:01');
INSERT INTO `link_single_table` VALUES (20, 2, 1, 94, 94, 0, 2, '00:00:0a:02:03:01');
INSERT INTO `link_single_table` VALUES (21, 2, 4, 57, 57, 0, 3, '00:00:0a:05:03:01');
INSERT INTO `link_single_table` VALUES (22, 2, 6, 63, 63, 0, 4, '00:00:0a:07:02:01');
INSERT INTO `link_single_table` VALUES (23, 2, 7, 64, 64, 0, 5, '00:00:0a:08:02:01');
INSERT INTO `link_single_table` VALUES (24, 2, 10, 95, 95, 0, 6, '00:00:0a:11:02:01');
INSERT INTO `link_single_table` VALUES (25, 2, 12, 60, 60, 0, 7, '00:00:0a:13:04:01');
INSERT INTO `link_single_table` VALUES (26, 2, 18, 91, 91, 0, 8, '00:00:0a:19:03:01');
INSERT INTO `link_single_table` VALUES (27, 2, 22, 82, 82, 0, 9, '00:00:0a:23:02:01');
INSERT INTO `link_single_table` VALUES (28, 3, 0, 82, 82, 0, 2, '00:00:0a:01:03:01');
INSERT INTO `link_single_table` VALUES (29, 3, 1, 99, 99, 0, 3, '00:00:0a:02:04:01');
INSERT INTO `link_single_table` VALUES (30, 3, 5, 82, 82, 0, 4, '00:00:0a:06:03:01');
INSERT INTO `link_single_table` VALUES (31, 3, 8, 83, 83, 0, 5, '00:00:0a:09:02:01');
INSERT INTO `link_single_table` VALUES (32, 3, 11, 57, 57, 0, 6, '00:00:0a:12:04:01');
INSERT INTO `link_single_table` VALUES (33, 3, 17, 77, 77, 0, 7, '00:00:0a:18:02:01');
INSERT INTO `link_single_table` VALUES (34, 3, 18, 98, 98, 0, 8, '00:00:0a:19:04:01');
INSERT INTO `link_single_table` VALUES (35, 3, 20, 95, 95, 0, 9, '00:00:0a:21:03:01');
INSERT INTO `link_single_table` VALUES (36, 3, 24, 68, 68, 0, 10, '00:00:0a:25:03:01');
INSERT INTO `link_single_table` VALUES (37, 4, 1, 55, 55, 0, 2, '00:00:0a:02:05:01');
INSERT INTO `link_single_table` VALUES (38, 4, 2, 77, 77, 0, 3, '00:00:0a:03:03:01');
INSERT INTO `link_single_table` VALUES (39, 4, 5, 54, 54, 0, 4, '00:00:0a:06:04:01');
INSERT INTO `link_single_table` VALUES (40, 4, 7, 57, 57, 0, 5, '00:00:0a:08:03:01');
INSERT INTO `link_single_table` VALUES (41, 4, 8, 85, 85, 0, 6, '00:00:0a:09:03:01');
INSERT INTO `link_single_table` VALUES (42, 4, 12, 74, 74, 0, 7, '00:00:0a:13:05:01');
INSERT INTO `link_single_table` VALUES (43, 4, 14, 95, 95, 0, 8, '00:00:0a:15:03:01');
INSERT INTO `link_single_table` VALUES (44, 4, 16, 99, 99, 0, 9, '00:00:0a:17:03:01');
INSERT INTO `link_single_table` VALUES (45, 4, 19, 59, 59, 0, 10, '00:00:0a:20:03:01');
INSERT INTO `link_single_table` VALUES (46, 4, 24, 56, 56, 0, 11, '00:00:0a:25:04:01');
INSERT INTO `link_single_table` VALUES (47, 5, 0, 59, 59, 0, 2, '00:00:0a:01:04:01');
INSERT INTO `link_single_table` VALUES (48, 5, 3, 50, 50, 0, 3, '00:00:0a:04:04:01');
INSERT INTO `link_single_table` VALUES (49, 5, 4, 59, 59, 0, 4, '00:00:0a:05:04:01');
INSERT INTO `link_single_table` VALUES (50, 5, 6, 86, 86, 0, 5, '00:00:0a:07:03:01');
INSERT INTO `link_single_table` VALUES (51, 5, 7, 78, 78, 0, 6, '00:00:0a:08:04:01');
INSERT INTO `link_single_table` VALUES (52, 5, 8, 94, 94, 0, 7, '00:00:0a:09:04:01');
INSERT INTO `link_single_table` VALUES (53, 5, 12, 70, 70, 0, 8, '00:00:0a:13:06:01');
INSERT INTO `link_single_table` VALUES (54, 5, 14, 63, 63, 0, 9, '00:00:0a:15:04:01');
INSERT INTO `link_single_table` VALUES (55, 5, 18, 82, 82, 0, 10, '00:00:0a:19:05:01');
INSERT INTO `link_single_table` VALUES (56, 5, 19, 92, 92, 0, 11, '00:00:0a:20:04:01');
INSERT INTO `link_single_table` VALUES (57, 6, 2, 84, 84, 0, 2, '00:00:0a:03:04:01');
INSERT INTO `link_single_table` VALUES (58, 6, 5, 74, 74, 0, 3, '00:00:0a:06:05:01');
INSERT INTO `link_single_table` VALUES (59, 6, 7, 81, 81, 0, 4, '00:00:0a:08:05:01');
INSERT INTO `link_single_table` VALUES (60, 6, 9, 80, 80, 0, 5, '00:00:0a:10:02:01');
INSERT INTO `link_single_table` VALUES (61, 6, 13, 85, 85, 0, 6, '00:00:0a:14:02:01');
INSERT INTO `link_single_table` VALUES (62, 6, 16, 80, 80, 0, 7, '00:00:0a:17:04:01');
INSERT INTO `link_single_table` VALUES (63, 6, 20, 81, 81, 0, 8, '00:00:0a:21:04:01');
INSERT INTO `link_single_table` VALUES (64, 6, 21, 63, 63, 0, 9, '00:00:0a:22:04:01');
INSERT INTO `link_single_table` VALUES (65, 6, 23, 75, 75, 0, 10, '00:00:0a:24:02:01');
INSERT INTO `link_single_table` VALUES (66, 7, 2, 99, 99, 0, 2, '00:00:0a:03:05:01');
INSERT INTO `link_single_table` VALUES (67, 7, 4, 60, 60, 0, 3, '00:00:0a:05:05:01');
INSERT INTO `link_single_table` VALUES (68, 7, 5, 61, 61, 0, 4, '00:00:0a:06:06:01');
INSERT INTO `link_single_table` VALUES (69, 7, 6, 93, 93, 0, 5, '00:00:0a:07:04:01');
INSERT INTO `link_single_table` VALUES (70, 7, 8, 58, 58, 0, 6, '00:00:0a:09:05:01');
INSERT INTO `link_single_table` VALUES (71, 7, 11, 61, 61, 0, 7, '00:00:0a:12:05:01');
INSERT INTO `link_single_table` VALUES (72, 7, 12, 61, 61, 0, 8, '00:00:0a:13:07:01');
INSERT INTO `link_single_table` VALUES (73, 7, 14, 72, 72, 0, 9, '00:00:0a:15:05:01');
INSERT INTO `link_single_table` VALUES (74, 7, 17, 71, 71, 0, 10, '00:00:0a:18:03:01');
INSERT INTO `link_single_table` VALUES (75, 7, 18, 90, 90, 0, 11, '00:00:0a:19:06:01');
INSERT INTO `link_single_table` VALUES (76, 7, 19, 54, 54, 0, 12, '00:00:0a:20:05:01');
INSERT INTO `link_single_table` VALUES (77, 7, 20, 60, 60, 0, 13, '00:00:0a:21:05:01');
INSERT INTO `link_single_table` VALUES (78, 7, 21, 88, 88, 0, 14, '00:00:0a:22:05:01');
INSERT INTO `link_single_table` VALUES (79, 7, 22, 92, 92, 0, 15, '00:00:0a:23:03:01');
INSERT INTO `link_single_table` VALUES (80, 7, 24, 57, 57, 0, 16, '00:00:0a:25:05:01');
INSERT INTO `link_single_table` VALUES (81, 8, 3, 67, 67, 0, 2, '00:00:0a:04:05:01');
INSERT INTO `link_single_table` VALUES (82, 8, 4, 63, 63, 0, 3, '00:00:0a:05:06:01');
INSERT INTO `link_single_table` VALUES (83, 8, 5, 67, 67, 0, 4, '00:00:0a:06:07:01');
INSERT INTO `link_single_table` VALUES (84, 8, 7, 78, 78, 0, 5, '00:00:0a:08:06:01');
INSERT INTO `link_single_table` VALUES (85, 8, 10, 87, 87, 0, 6, '00:00:0a:11:03:01');
INSERT INTO `link_single_table` VALUES (86, 8, 11, 78, 78, 0, 7, '00:00:0a:12:06:01');
INSERT INTO `link_single_table` VALUES (87, 8, 18, 77, 77, 0, 8, '00:00:0a:19:07:01');
INSERT INTO `link_single_table` VALUES (88, 8, 19, 56, 56, 0, 9, '00:00:0a:20:06:01');
INSERT INTO `link_single_table` VALUES (89, 8, 20, 58, 58, 0, 10, '00:00:0a:21:06:01');
INSERT INTO `link_single_table` VALUES (90, 9, 6, 68, 68, 0, 2, '00:00:0a:07:05:01');
INSERT INTO `link_single_table` VALUES (91, 9, 13, 75, 75, 0, 3, '00:00:0a:14:03:01');
INSERT INTO `link_single_table` VALUES (92, 9, 20, 81, 81, 0, 4, '00:00:0a:21:07:01');
INSERT INTO `link_single_table` VALUES (93, 9, 22, 100, 100, 0, 5, '00:00:0a:23:04:01');
INSERT INTO `link_single_table` VALUES (94, 9, 23, 84, 84, 0, 6, '00:00:0a:24:03:01');
INSERT INTO `link_single_table` VALUES (95, 10, 2, 91, 91, 0, 2, '00:00:0a:03:06:01');
INSERT INTO `link_single_table` VALUES (96, 10, 8, 81, 81, 0, 3, '00:00:0a:09:06:01');
INSERT INTO `link_single_table` VALUES (97, 10, 11, 86, 86, 0, 4, '00:00:0a:12:07:01');
INSERT INTO `link_single_table` VALUES (98, 10, 12, 50, 50, 0, 5, '00:00:0a:13:08:01');
INSERT INTO `link_single_table` VALUES (99, 10, 18, 94, 94, 0, 6, '00:00:0a:19:08:01');
INSERT INTO `link_single_table` VALUES (100, 10, 19, 87, 87, 0, 7, '00:00:0a:20:07:01');
INSERT INTO `link_single_table` VALUES (101, 10, 21, 85, 85, 0, 8, '00:00:0a:22:06:01');
INSERT INTO `link_single_table` VALUES (102, 11, 0, 70, 70, 0, 2, '00:00:0a:01:05:01');
INSERT INTO `link_single_table` VALUES (103, 11, 1, 60, 60, 0, 3, '00:00:0a:02:06:01');
INSERT INTO `link_single_table` VALUES (104, 11, 3, 53, 53, 0, 4, '00:00:0a:04:06:01');
INSERT INTO `link_single_table` VALUES (105, 11, 7, 76, 76, 0, 5, '00:00:0a:08:07:01');
INSERT INTO `link_single_table` VALUES (106, 11, 8, 83, 83, 0, 6, '00:00:0a:09:07:01');
INSERT INTO `link_single_table` VALUES (107, 11, 10, 61, 61, 0, 7, '00:00:0a:11:04:01');
INSERT INTO `link_single_table` VALUES (108, 11, 12, 54, 54, 0, 8, '00:00:0a:13:09:01');
INSERT INTO `link_single_table` VALUES (109, 11, 14, 74, 74, 0, 9, '00:00:0a:15:06:01');
INSERT INTO `link_single_table` VALUES (110, 11, 15, 73, 73, 0, 10, '00:00:0a:16:02:01');
INSERT INTO `link_single_table` VALUES (111, 11, 20, 98, 98, 0, 11, '00:00:0a:21:08:01');
INSERT INTO `link_single_table` VALUES (112, 11, 22, 57, 57, 0, 12, '00:00:0a:23:05:01');
INSERT INTO `link_single_table` VALUES (113, 11, 24, 99, 99, 0, 13, '00:00:0a:25:06:01');
INSERT INTO `link_single_table` VALUES (114, 12, 0, 66, 66, 0, 2, '00:00:0a:01:06:01');
INSERT INTO `link_single_table` VALUES (115, 12, 1, 71, 71, 0, 3, '00:00:0a:02:07:01');
INSERT INTO `link_single_table` VALUES (116, 12, 2, 96, 96, 0, 4, '00:00:0a:03:07:01');
INSERT INTO `link_single_table` VALUES (117, 12, 4, 96, 96, 0, 5, '00:00:0a:05:07:01');
INSERT INTO `link_single_table` VALUES (118, 12, 5, 98, 98, 0, 6, '00:00:0a:06:08:01');
INSERT INTO `link_single_table` VALUES (119, 12, 7, 86, 86, 0, 7, '00:00:0a:08:08:01');
INSERT INTO `link_single_table` VALUES (120, 12, 10, 84, 84, 0, 8, '00:00:0a:11:05:01');
INSERT INTO `link_single_table` VALUES (121, 12, 11, 57, 57, 0, 9, '00:00:0a:12:08:01');
INSERT INTO `link_single_table` VALUES (122, 12, 15, 97, 97, 0, 10, '00:00:0a:16:03:01');
INSERT INTO `link_single_table` VALUES (123, 12, 18, 53, 53, 0, 11, '00:00:0a:19:09:01');
INSERT INTO `link_single_table` VALUES (124, 12, 19, 95, 95, 0, 12, '00:00:0a:20:08:01');
INSERT INTO `link_single_table` VALUES (125, 12, 22, 81, 81, 0, 13, '00:00:0a:23:06:01');
INSERT INTO `link_single_table` VALUES (126, 12, 23, 85, 85, 0, 14, '00:00:0a:24:04:01');
INSERT INTO `link_single_table` VALUES (127, 13, 6, 60, 60, 0, 2, '00:00:0a:07:06:01');
INSERT INTO `link_single_table` VALUES (128, 13, 9, 72, 72, 0, 3, '00:00:0a:10:03:01');
INSERT INTO `link_single_table` VALUES (129, 13, 22, 62, 62, 0, 4, '00:00:0a:23:07:01');
INSERT INTO `link_single_table` VALUES (130, 13, 23, 84, 84, 0, 5, '00:00:0a:24:05:01');
INSERT INTO `link_single_table` VALUES (131, 14, 1, 97, 97, 0, 2, '00:00:0a:02:08:01');
INSERT INTO `link_single_table` VALUES (132, 14, 4, 62, 62, 0, 3, '00:00:0a:05:08:01');
INSERT INTO `link_single_table` VALUES (133, 14, 5, 87, 87, 0, 4, '00:00:0a:06:09:01');
INSERT INTO `link_single_table` VALUES (134, 14, 7, 66, 66, 0, 5, '00:00:0a:08:09:01');
INSERT INTO `link_single_table` VALUES (135, 14, 11, 99, 99, 0, 6, '00:00:0a:12:09:01');
INSERT INTO `link_single_table` VALUES (136, 14, 15, 92, 92, 0, 7, '00:00:0a:16:04:01');
INSERT INTO `link_single_table` VALUES (137, 14, 16, 66, 66, 0, 8, '00:00:0a:17:05:01');
INSERT INTO `link_single_table` VALUES (138, 14, 18, 89, 89, 0, 9, '00:00:0a:19:10:01');
INSERT INTO `link_single_table` VALUES (139, 14, 21, 64, 64, 0, 10, '00:00:0a:22:07:01');
INSERT INTO `link_single_table` VALUES (140, 15, 11, 66, 66, 0, 2, '00:00:0a:12:10:01');
INSERT INTO `link_single_table` VALUES (141, 15, 12, 86, 86, 0, 3, '00:00:0a:13:10:01');
INSERT INTO `link_single_table` VALUES (142, 15, 14, 88, 88, 0, 4, '00:00:0a:15:07:01');
INSERT INTO `link_single_table` VALUES (143, 15, 18, 98, 98, 0, 5, '00:00:0a:19:11:01');
INSERT INTO `link_single_table` VALUES (144, 15, 20, 83, 83, 0, 6, '00:00:0a:21:09:01');
INSERT INTO `link_single_table` VALUES (145, 15, 22, 98, 98, 0, 7, '00:00:0a:23:08:01');
INSERT INTO `link_single_table` VALUES (146, 16, 1, 82, 82, 0, 2, '00:00:0a:02:09:01');
INSERT INTO `link_single_table` VALUES (147, 16, 4, 86, 86, 0, 3, '00:00:0a:05:09:01');
INSERT INTO `link_single_table` VALUES (148, 16, 6, 61, 61, 0, 4, '00:00:0a:07:07:01');
INSERT INTO `link_single_table` VALUES (149, 16, 14, 72, 72, 0, 5, '00:00:0a:15:08:01');
INSERT INTO `link_single_table` VALUES (150, 16, 21, 100, 100, 0, 6, '00:00:0a:22:08:01');
INSERT INTO `link_single_table` VALUES (151, 16, 22, 54, 54, 0, 7, '00:00:0a:23:09:01');
INSERT INTO `link_single_table` VALUES (152, 17, 3, 65, 65, 0, 2, '00:00:0a:04:07:01');
INSERT INTO `link_single_table` VALUES (153, 17, 7, 86, 86, 0, 3, '00:00:0a:08:10:01');
INSERT INTO `link_single_table` VALUES (154, 17, 19, 67, 67, 0, 4, '00:00:0a:20:09:01');
INSERT INTO `link_single_table` VALUES (155, 17, 20, 98, 98, 0, 5, '00:00:0a:21:10:01');
INSERT INTO `link_single_table` VALUES (156, 17, 23, 56, 56, 0, 6, '00:00:0a:24:06:01');
INSERT INTO `link_single_table` VALUES (157, 18, 1, 91, 91, 0, 2, '00:00:0a:02:10:01');
INSERT INTO `link_single_table` VALUES (158, 18, 2, 62, 62, 0, 3, '00:00:0a:03:08:01');
INSERT INTO `link_single_table` VALUES (159, 18, 3, 65, 65, 0, 4, '00:00:0a:04:08:01');
INSERT INTO `link_single_table` VALUES (160, 18, 5, 97, 97, 0, 5, '00:00:0a:06:10:01');
INSERT INTO `link_single_table` VALUES (161, 18, 7, 94, 94, 0, 6, '00:00:0a:08:11:01');
INSERT INTO `link_single_table` VALUES (162, 18, 8, 58, 58, 0, 7, '00:00:0a:09:08:01');
INSERT INTO `link_single_table` VALUES (163, 18, 10, 63, 63, 0, 8, '00:00:0a:11:06:01');
INSERT INTO `link_single_table` VALUES (164, 18, 12, 93, 93, 0, 9, '00:00:0a:13:11:01');
INSERT INTO `link_single_table` VALUES (165, 18, 14, 80, 80, 0, 10, '00:00:0a:15:09:01');
INSERT INTO `link_single_table` VALUES (166, 18, 15, 79, 79, 0, 11, '00:00:0a:16:05:01');
INSERT INTO `link_single_table` VALUES (167, 18, 19, 65, 65, 0, 12, '00:00:0a:20:10:01');
INSERT INTO `link_single_table` VALUES (168, 18, 20, 57, 57, 0, 13, '00:00:0a:21:11:01');
INSERT INTO `link_single_table` VALUES (169, 18, 21, 58, 58, 0, 14, '00:00:0a:22:09:01');
INSERT INTO `link_single_table` VALUES (170, 18, 22, 80, 80, 0, 15, '00:00:0a:23:10:01');
INSERT INTO `link_single_table` VALUES (171, 18, 23, 50, 50, 0, 16, '00:00:0a:24:07:01');
INSERT INTO `link_single_table` VALUES (172, 19, 1, 70, 70, 0, 2, '00:00:0a:02:11:01');
INSERT INTO `link_single_table` VALUES (173, 19, 4, 82, 82, 0, 3, '00:00:0a:05:10:01');
INSERT INTO `link_single_table` VALUES (174, 19, 5, 52, 52, 0, 4, '00:00:0a:06:11:01');
INSERT INTO `link_single_table` VALUES (175, 19, 7, 100, 100, 0, 5, '00:00:0a:08:12:01');
INSERT INTO `link_single_table` VALUES (176, 19, 8, 94, 94, 0, 6, '00:00:0a:09:09:01');
INSERT INTO `link_single_table` VALUES (177, 19, 10, 69, 69, 0, 7, '00:00:0a:11:07:01');
INSERT INTO `link_single_table` VALUES (178, 19, 12, 65, 65, 0, 8, '00:00:0a:13:12:01');
INSERT INTO `link_single_table` VALUES (179, 19, 17, 63, 63, 0, 9, '00:00:0a:18:04:01');
INSERT INTO `link_single_table` VALUES (180, 19, 18, 93, 93, 0, 10, '00:00:0a:19:12:01');
INSERT INTO `link_single_table` VALUES (181, 19, 20, 93, 93, 0, 11, '00:00:0a:21:12:01');
INSERT INTO `link_single_table` VALUES (182, 19, 22, 69, 69, 0, 12, '00:00:0a:23:11:01');
INSERT INTO `link_single_table` VALUES (183, 20, 1, 58, 58, 0, 2, '00:00:0a:02:12:01');
INSERT INTO `link_single_table` VALUES (184, 20, 3, 69, 69, 0, 3, '00:00:0a:04:09:01');
INSERT INTO `link_single_table` VALUES (185, 20, 6, 92, 92, 0, 4, '00:00:0a:07:08:01');
INSERT INTO `link_single_table` VALUES (186, 20, 7, 67, 67, 0, 5, '00:00:0a:08:13:01');
INSERT INTO `link_single_table` VALUES (187, 20, 8, 75, 75, 0, 6, '00:00:0a:09:10:01');
INSERT INTO `link_single_table` VALUES (188, 20, 9, 71, 71, 0, 7, '00:00:0a:10:04:01');
INSERT INTO `link_single_table` VALUES (189, 20, 11, 88, 88, 0, 8, '00:00:0a:12:11:01');
INSERT INTO `link_single_table` VALUES (190, 20, 15, 80, 80, 0, 9, '00:00:0a:16:06:01');
INSERT INTO `link_single_table` VALUES (191, 20, 17, 64, 64, 0, 10, '00:00:0a:18:05:01');
INSERT INTO `link_single_table` VALUES (192, 20, 18, 77, 77, 0, 11, '00:00:0a:19:13:01');
INSERT INTO `link_single_table` VALUES (193, 20, 19, 84, 84, 0, 12, '00:00:0a:20:11:01');
INSERT INTO `link_single_table` VALUES (194, 20, 21, 63, 63, 0, 13, '00:00:0a:22:10:01');
INSERT INTO `link_single_table` VALUES (195, 20, 24, 55, 55, 0, 14, '00:00:0a:25:07:01');
INSERT INTO `link_single_table` VALUES (196, 21, 0, 90, 90, 0, 2, '00:00:0a:01:07:01');
INSERT INTO `link_single_table` VALUES (197, 21, 1, 65, 65, 0, 3, '00:00:0a:02:13:01');
INSERT INTO `link_single_table` VALUES (198, 21, 6, 95, 95, 0, 4, '00:00:0a:07:09:01');
INSERT INTO `link_single_table` VALUES (199, 21, 7, 81, 81, 0, 5, '00:00:0a:08:14:01');
INSERT INTO `link_single_table` VALUES (200, 21, 10, 93, 93, 0, 6, '00:00:0a:11:08:01');
INSERT INTO `link_single_table` VALUES (201, 21, 14, 68, 68, 0, 7, '00:00:0a:15:10:01');
INSERT INTO `link_single_table` VALUES (202, 21, 16, 87, 87, 0, 8, '00:00:0a:17:06:01');
INSERT INTO `link_single_table` VALUES (203, 21, 18, 61, 61, 0, 9, '00:00:0a:19:14:01');
INSERT INTO `link_single_table` VALUES (204, 21, 20, 82, 82, 0, 10, '00:00:0a:21:13:01');
INSERT INTO `link_single_table` VALUES (205, 22, 2, 75, 75, 0, 2, '00:00:0a:03:09:01');
INSERT INTO `link_single_table` VALUES (206, 22, 7, 57, 57, 0, 3, '00:00:0a:08:15:01');
INSERT INTO `link_single_table` VALUES (207, 22, 9, 59, 59, 0, 4, '00:00:0a:10:05:01');
INSERT INTO `link_single_table` VALUES (208, 22, 11, 51, 51, 0, 5, '00:00:0a:12:12:01');
INSERT INTO `link_single_table` VALUES (209, 22, 12, 91, 91, 0, 6, '00:00:0a:13:13:01');
INSERT INTO `link_single_table` VALUES (210, 22, 13, 71, 71, 0, 7, '00:00:0a:14:04:01');
INSERT INTO `link_single_table` VALUES (211, 22, 15, 85, 85, 0, 8, '00:00:0a:16:07:01');
INSERT INTO `link_single_table` VALUES (212, 22, 16, 98, 98, 0, 9, '00:00:0a:17:07:01');
INSERT INTO `link_single_table` VALUES (213, 22, 18, 84, 84, 0, 10, '00:00:0a:19:15:01');
INSERT INTO `link_single_table` VALUES (214, 22, 19, 83, 83, 0, 11, '00:00:0a:20:12:01');
INSERT INTO `link_single_table` VALUES (215, 23, 6, 61, 61, 0, 2, '00:00:0a:07:10:01');
INSERT INTO `link_single_table` VALUES (216, 23, 9, 67, 67, 0, 3, '00:00:0a:10:06:01');
INSERT INTO `link_single_table` VALUES (217, 23, 12, 87, 87, 0, 4, '00:00:0a:13:14:01');
INSERT INTO `link_single_table` VALUES (218, 23, 13, 72, 72, 0, 5, '00:00:0a:14:05:01');
INSERT INTO `link_single_table` VALUES (219, 23, 17, 96, 96, 0, 6, '00:00:0a:18:06:01');
INSERT INTO `link_single_table` VALUES (220, 23, 18, 50, 50, 0, 7, '00:00:0a:19:16:01');
INSERT INTO `link_single_table` VALUES (221, 24, 0, 79, 79, 0, 2, '00:00:0a:01:08:01');
INSERT INTO `link_single_table` VALUES (222, 24, 3, 59, 59, 0, 3, '00:00:0a:04:10:01');
INSERT INTO `link_single_table` VALUES (223, 24, 4, 56, 56, 0, 4, '00:00:0a:05:11:01');
INSERT INTO `link_single_table` VALUES (224, 24, 7, 83, 83, 0, 5, '00:00:0a:08:16:01');
INSERT INTO `link_single_table` VALUES (225, 24, 11, 83, 83, 0, 6, '00:00:0a:12:13:01');
INSERT INTO `link_single_table` VALUES (226, 24, 20, 51, 51, 0, 7, '00:00:0a:21:14:01');

SET FOREIGN_KEY_CHECKS = 1;
