/*
 Navicat Premium Dump SQL

 Source Server         : local
 Source Server Type    : MySQL
 Source Server Version : 80040 (8.0.40)
 Source Host           : localhost:3306
 Source Schema         : nfv_link

 Target Server Type    : MySQL
 Target Server Version : 80040 (8.0.40)
 File Encoding         : 65001

 Date: 24/10/2026 15:06:01
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for node_single_table
-- ----------------------------
DROP TABLE IF EXISTS `node_single_table`;
CREATE TABLE `node_single_table`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `node_id` int NULL DEFAULT NULL,
  `pos_x` float NULL DEFAULT NULL,
  `pos_y` float NULL DEFAULT NULL,
  `cpu` int NULL DEFAULT NULL,
  `max_cpu` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 26 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of node_single_table
-- ----------------------------
INSERT INTO `node_single_table` VALUES (1, 0, 8.44812, 2.72084, 57, 57);
INSERT INTO `node_single_table` VALUES (2, 1, 11.7467, 4.63774, 52, 52);
INSERT INTO `node_single_table` VALUES (3, 2, 14.794, 13.8945, 83, 83);
INSERT INTO `node_single_table` VALUES (4, 3, 1.85932, 2.32095, 97, 97);
INSERT INTO `node_single_table` VALUES (5, 4, 8.14171, 8.96144, 50, 50);
INSERT INTO `node_single_table` VALUES (6, 5, 7.8455, 13.0389, 84, 84);
INSERT INTO `node_single_table` VALUES (7, 6, 17.9863, 6.11791, 87, 87);
INSERT INTO `node_single_table` VALUES (8, 7, 3.21172, 14.197, 56, 56);
INSERT INTO `node_single_table` VALUES (9, 8, 2.11782, 10.9016, 97, 97);
INSERT INTO `node_single_table` VALUES (10, 9, 20.4582, 15.3892, 75, 75);
INSERT INTO `node_single_table` VALUES (11, 10, 11.2968, 21.5357, 83, 83);
INSERT INTO `node_single_table` VALUES (12, 11, 5.17492, 8.586, 60, 60);
INSERT INTO `node_single_table` VALUES (13, 12, 14.1785, 13.903, 84, 84);
INSERT INTO `node_single_table` VALUES (14, 13, 20.0122, 11.2128, 76, 76);
INSERT INTO `node_single_table` VALUES (15, 14, 9.2422, 2.38459, 90, 90);
INSERT INTO `node_single_table` VALUES (16, 15, 7.33479, 7.74891, 80, 80);
INSERT INTO `node_single_table` VALUES (17, 16, 14.097, 0.324161, 98, 98);
INSERT INTO `node_single_table` VALUES (18, 17, 0.744859, 15.5898, 69, 69);
INSERT INTO `node_single_table` VALUES (19, 18, 13.3617, 16.0059, 92, 92);
INSERT INTO `node_single_table` VALUES (20, 19, 10.4385, 11.1345, 60, 60);
INSERT INTO `node_single_table` VALUES (21, 20, 3.58539, 8.68384, 96, 96);
INSERT INTO `node_single_table` VALUES (22, 21, 12.8395, 5.82148, 69, 69);
INSERT INTO `node_single_table` VALUES (23, 22, 14.4968, 17.3293, 73, 73);
INSERT INTO `node_single_table` VALUES (24, 23, 21.3902, 15.2753, 72, 72);
INSERT INTO `node_single_table` VALUES (25, 24, 0.914441, 3.7072, 81, 81);

SET FOREIGN_KEY_CHECKS = 1;
